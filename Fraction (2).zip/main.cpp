#include <iostream>
#include "Fraction.h"

using namespace std;

int main()
{
    ios();
    relational();
    arithmetic();
    excep();
    return 0;
}
